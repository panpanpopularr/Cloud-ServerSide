/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',   // สำคัญ!
  reactStrictMode: true,
};
export default nextConfig;
