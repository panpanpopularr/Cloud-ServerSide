/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: false, // ปิดเพื่อไม่ให้ useEffect เรียกซ้ำใน dev
};
export default nextConfig;
